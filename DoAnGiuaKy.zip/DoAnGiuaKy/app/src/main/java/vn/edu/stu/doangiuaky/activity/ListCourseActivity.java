package vn.edu.stu.doangiuaky.activity;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.List;

import vn.edu.stu.doangiuaky.R;
import vn.edu.stu.doangiuaky.adapter.CourseAdapter;
import vn.edu.stu.doangiuaky.dao.ClassifyDao;
import vn.edu.stu.doangiuaky.dao.CourseDao;
import vn.edu.stu.doangiuaky.model.Classify;
import vn.edu.stu.doangiuaky.model.Course;

public class ListCourseActivity extends AppCompatActivity {
    private ListView lvMonHoc;
    private List<Course> list;
    private CourseAdapter cAdapter;
    private CourseDao dao;
    int requestCode = 113, resultCode = 115;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_course);
        addControls();
        addEvents();
        hienThiDSMonHoc();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == this.requestCode) {
            if (resultCode == this.resultCode) {
                if (data.hasExtra("TRA")) {
                    Course c = (Course) data.getSerializableExtra("TRA");
                    dao.update(c.getMamh().toString(),c);
                    hienThiDSMonHoc();
                }
            }
        }
    }

    private void hienThiDSMonHoc() {
        dao = new CourseDao(ListCourseActivity.this);
        list = dao.getAll();
        cAdapter = new CourseAdapter(ListCourseActivity.this,list);
        lvMonHoc.setAdapter(cAdapter);
    }

    private void addEvents() {
        lvMonHoc.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                if(i >= 0 && i < cAdapter.getCount()){
                    Intent intent = new Intent(ListCourseActivity.this,CourseActivity.class);
                    Course c = (Course) cAdapter.getItem(i);
                    boolean isEdit = true;
                    intent.putExtra("CHON",c);
                    intent.putExtra("EDIT",isEdit);
                    startActivityForResult(intent,requestCode);
                }
            }
        });

        lvMonHoc.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                if( i >= 0 && i < cAdapter.getCount()){
                    ClassifyDao dao = new ClassifyDao(ListCourseActivity.this);
                    Course c =(Course) cAdapter.getItem(i);
                    xuLyXoa(c.getMamh().toString());
                }
                return true;
            }
        });
    }

    private void xuLyXoa(String mamh) {
        AlertDialog.Builder builder = new AlertDialog.Builder(ListCourseActivity.this);
        builder.setTitle("Thông báo");
        builder.setMessage("Bạn có chắc muốn xoá");
        builder.setIcon(R.drawable.alert_icon);
        builder.setPositiveButton("YES", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dao.delete(mamh);
                hienThiDSMonHoc();
                Context context = getApplicationContext();
                Toast toast = Toast.makeText(context, "Xoá thành công !", Toast.LENGTH_SHORT);
                toast.show();
            }
        });
        builder.setNegativeButton("NO", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        });
        AlertDialog dialog = builder.create();
        dialog.setCanceledOnTouchOutside(false);
        dialog.show();
    }

    private void addControls() {
        lvMonHoc = findViewById(R.id.lvMonHoc);
    }
}