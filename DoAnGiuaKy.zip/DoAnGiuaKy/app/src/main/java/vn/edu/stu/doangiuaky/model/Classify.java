package vn.edu.stu.doangiuaky.model;

import java.io.Serializable;

public class Classify implements Serializable {
    private Integer mapl;
    private String tenpl;

    public Classify() {
    }

    public Classify(Integer mapl, String tenpl) {
        this.mapl = mapl;
        this.tenpl = tenpl;
    }

    public Integer getMapl() {
        return mapl;
    }

    public void setMapl(Integer mapl) {
        this.mapl = mapl;
    }

    public String getTenpl() {
        return tenpl;
    }

    public void setTenpl(String tenpl) {
        this.tenpl = tenpl;
    }

    @Override
    public String toString() {
        return "Mã phân loại: "+mapl+"\n"+"Tên phân loại: "+tenpl;
    }
}
