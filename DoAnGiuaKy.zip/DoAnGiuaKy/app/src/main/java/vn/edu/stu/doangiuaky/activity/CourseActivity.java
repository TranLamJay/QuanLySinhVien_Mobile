package vn.edu.stu.doangiuaky.activity;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import vn.edu.stu.doangiuaky.R;
import vn.edu.stu.doangiuaky.adapter.ClassifyAdapter;
import vn.edu.stu.doangiuaky.dao.ClassifyDao;
import vn.edu.stu.doangiuaky.dao.CourseDao;
import vn.edu.stu.doangiuaky.model.Classify;
import vn.edu.stu.doangiuaky.model.Course;

public class CourseActivity extends AppCompatActivity {
    private Spinner spnPhanLoai;
    private Course c = null;
    private ClassifyDao daoPl;
    private List<Classify> classifyList;
    private ClassifyAdapter classifyAdapter;
    private Button btnLuuMonHoc, btnUploadImage;
    private EditText etMaMonHoc, etTenMonHoc, etGiaMonHoc, etSoTietMonHoc;
    private ImageView hinh;
    private int GALLERY_REQ_CODE = 1000;
    private byte[] inputData;
    int resultCode = 115;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_course);
        addControls();
        addEvents();
        getIntentData();
    }

    private void getIntentData() {
        Intent intent = getIntent();
        if(intent.hasExtra("CHON")) {
            c =(Course) intent.getSerializableExtra("CHON");
            if(c != null) {
                etMaMonHoc.setText(c.getMamh().toString());
                etTenMonHoc.setText(c.getTenmh());
                etGiaMonHoc.setText(c.getGia().toString());
                etSoTietMonHoc.setText(c.getSotiet().toString());
//                spnPhanLoai.setSelection(c.getPl().getMapl() - 1);
                InputStream is = new ByteArrayInputStream(c.getHinh());
                Bitmap bmp = BitmapFactory.decodeStream(is);
                hinh.setImageBitmap(bmp);
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode == RESULT_OK) {
            if(requestCode == GALLERY_REQ_CODE) {
                hinh.setImageURI(data.getData());
                try {
                    InputStream inputStream =getContentResolver().openInputStream(data.getData());
                    inputData = getBytes(inputStream);
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private byte[] getBytes(InputStream inputStream) throws IOException {
        ByteArrayOutputStream byteBuffer = new ByteArrayOutputStream();
        int bufferSize = 1024;
        byte[] buffer = new byte[bufferSize];
        int len = 0;
        while ((len = inputStream.read(buffer)) != -1) {
            byteBuffer.write(buffer, 0, len);
        }
        return byteBuffer.toByteArray();
    }

    private void addEvents() {
        btnUploadImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_PICK);
                intent.setData(MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(intent, GALLERY_REQ_CODE);
            }
        });

        btnLuuMonHoc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                xuLyLuu();
            }
        });
    }


    private void xuLyLuu() {
        Intent intent = getIntent();
        if(intent.hasExtra("EDIT")) {
            c.setTenmh(etTenMonHoc.getText().toString());
            c.setGia(Integer.parseInt(etGiaMonHoc.getText().toString()));
            c.setSotiet(Integer.parseInt(etSoTietMonHoc.getText().toString()));
            c.setHinh(inputData);
            c.setPl((Classify) spnPhanLoai.getSelectedItem());
            intent.putExtra("TRA", c);
            setResult(resultCode, intent);
        }
        else {
            if(c == null) {
                c = new Course();
            }
            c.setTenmh(etTenMonHoc.getText().toString());
            c.setGia(Integer.parseInt(etGiaMonHoc.getText().toString()));
            c.setSotiet(Integer.parseInt(etSoTietMonHoc.getText().toString()));
            c.setHinh(inputData);
            c.setPl((Classify) spnPhanLoai.getSelectedItem());
            Context context = getApplicationContext();
            CourseDao dao = new CourseDao(context);
            dao.insert(c);
        }
        finish();
        Context context = getApplicationContext();
        Toast toast = Toast.makeText(context, "Lưu thành công !", Toast.LENGTH_SHORT);
        toast.show();
    }

    private void addControls() {
        spnPhanLoai = findViewById(R.id.spnPhanLoai);
        daoPl = new ClassifyDao(CourseActivity.this);
        classifyList = daoPl.getAll();
        classifyAdapter = new ClassifyAdapter(CourseActivity.this,classifyList);
        spnPhanLoai.setAdapter(classifyAdapter);
        btnLuuMonHoc = findViewById(R.id.btnLuuMonHoc);
        btnUploadImage = findViewById(R.id.btnUploadImage);
        etMaMonHoc = findViewById(R.id.etMaMonHoc);
        etMaMonHoc.setEnabled(false);
        etMaMonHoc.setFocusable(false);
        etTenMonHoc = findViewById(R.id.etTenMonHoc);
        etGiaMonHoc = findViewById(R.id.etGiaMonHoc);
        etSoTietMonHoc = findViewById(R.id.etSoTietMonHoc);
        hinh = findViewById(R.id.hinh);
    }
}