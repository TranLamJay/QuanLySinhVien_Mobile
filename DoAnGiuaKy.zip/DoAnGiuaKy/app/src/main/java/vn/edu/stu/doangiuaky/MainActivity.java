package vn.edu.stu.doangiuaky;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import vn.edu.stu.doangiuaky.activity.OptionActivity;

public class MainActivity extends AppCompatActivity {
    EditText etUsername, etPassword;
    Button btnLogin, btnExit;
    String fileUserState = "UserState";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        addControls();
        addEvents();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.option_menu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.menuAbout:
//                Intent intent = new Intent(MainActivity.this,)
                break;
            case R.id.menuExit:
                System.exit(0);
        }
        return super.onOptionsItemSelected(item);
    }

    private void addEvents() {
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                xuLyLogin();
            }
        });

        btnExit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                System.exit(0);
            }
        });
    }

    private void addControls() {
        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);
        btnExit = findViewById(R.id.btnExit);
    }

    private void xuLyLogin() {
        String username = etUsername.getText().toString();
        String password = etPassword.getText().toString();

        if(username.equalsIgnoreCase("admin") && password.equals("admin")) {
            Toast.makeText(this,"Succeeded",Toast.LENGTH_SHORT).show();

            SharedPreferences preferences = getSharedPreferences(fileUserState,MODE_PRIVATE);
            SharedPreferences.Editor editor = preferences.edit();
            editor.putString("username",username);
            editor.putString("password",password);
            editor.apply();
            Intent intent = new Intent(MainActivity.this, OptionActivity.class);
            startActivity(intent);
        }
        else {
            Toast.makeText(this,"Failed",Toast.LENGTH_SHORT).show();

            SharedPreferences preferences = getSharedPreferences(fileUserState,MODE_PRIVATE);
            SharedPreferences.Editor editor = preferences.edit();
            editor.remove("username");
            editor.remove("password");
            editor.apply();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        SharedPreferences preferences = getSharedPreferences(fileUserState,MODE_PRIVATE);
        String username = preferences.getString("username","");
        String password = preferences.getString("password","");
        etUsername.setText(username);
        etPassword.setText(password);
    }
}