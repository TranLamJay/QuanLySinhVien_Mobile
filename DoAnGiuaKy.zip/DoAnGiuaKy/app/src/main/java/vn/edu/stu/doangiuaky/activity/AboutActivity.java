package vn.edu.stu.doangiuaky.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import vn.edu.stu.doangiuaky.R;

public class AboutActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);
    }
}