package vn.edu.stu.doangiuaky.dao;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

import vn.edu.stu.doangiuaky.model.Classify;
import vn.edu.stu.doangiuaky.utils.DbUtil;

public class ClassifyDao {
    private SQLiteDatabase db;

    public ClassifyDao(Context context) {
        DbUtil dbu = new DbUtil(context);
        this.db = dbu.getWritableDatabase();
    }

    public long insert(Classify pl) {
        ContentValues values = new ContentValues();
        values.put("mapl",pl.getMapl());
        values.put("tenpl",pl.getTenpl());
        return db.insert("classifies",null,values);
    }

    @SuppressLint("Range")
    public List<Classify> get(String sql, String ... selectArgs) {
        List<Classify> list = new ArrayList<>();
        Cursor cursor = db.rawQuery(sql,selectArgs);
        while(cursor.moveToNext()) {
            Classify pl = new Classify();
            pl.setMapl(cursor.getInt(cursor.getColumnIndex("mapl")));
            pl.setTenpl(cursor.getString(cursor.getColumnIndex("tenpl")));
            list.add(pl);
        }
        return list;
    }

    public List<Classify> getAll() {
        String sql = "SELECT * FROM classifies";
        return get(sql);
    }

    public int delete(String mapl) {
        return db.delete("classifies","mapl=?",new String[]{mapl});
    }

    public long update(String mapl, Classify pl) {
        ContentValues values = new ContentValues();
        values.put("tenpl",pl.getTenpl());
        return db.update("classifies",values,"mapl=?",new String[]{mapl});
    }
}
