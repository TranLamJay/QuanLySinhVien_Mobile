package vn.edu.stu.doangiuaky.adapter;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.util.List;

import vn.edu.stu.doangiuaky.R;
import vn.edu.stu.doangiuaky.model.Course;

public class CourseAdapter extends BaseAdapter {
    private Context context;
    private List<Course> list;

    public CourseAdapter(Context context, List<Course> list) {
        this.context = context;
        this.list = list;
    }


    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int i) {
        return list.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        if(view == null) {
            view = LayoutInflater.from(context).inflate(R.layout.layout_course_item,null);
        }
        ImageView hinh = view.findViewById(R.id.hinh);
        TextView tvMaMonHoc = view.findViewById(R.id.tvMaMonHoc);
        TextView tvTenMonHoc = view.findViewById(R.id.tvTenMonHoc);
        TextView tvPhanLoai = view.findViewById(R.id.tvPhanLoai);
        Course c = list.get(i);
        InputStream is = new ByteArrayInputStream(c.getHinh());
        Bitmap bmp = BitmapFactory.decodeStream(is);
        hinh.setImageBitmap(bmp);
        tvMaMonHoc.setText(c.getMamh().toString());
        tvTenMonHoc.setText(c.getTenmh());
        tvPhanLoai.setText(c.getPl().getTenpl());
        return view;
    }
}
