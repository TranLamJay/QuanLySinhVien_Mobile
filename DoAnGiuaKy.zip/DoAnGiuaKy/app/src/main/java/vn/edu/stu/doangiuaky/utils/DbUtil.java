package vn.edu.stu.doangiuaky.utils;


import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DbUtil extends SQLiteOpenHelper {
    private static final String DB_NAME = "quanlykhoahoc";
    private static final int DB_VERSION = 1;

    public DbUtil(@Nullable Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        String classifiesSql = "CREATE TABLE classifies(mapl integer primary key autoincrement, tenpl text not null)";
        String coursesSql = "CREATE TABLE courses(mamh integer primary key autoincrement, tenmh text not null, gia integer not null, sotiet integer not null, hinh blob, tenpl text not null, classify_id integer not null, FOREIGN KEY (classify_id) REFERENCES classifies (mapl))";
        sqLiteDatabase.execSQL(classifiesSql);
        sqLiteDatabase.execSQL(coursesSql);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        String classifiesSql = "DROP TABLE IF EXISTS classifies";
        String coursesSql = "DROP TABLE IF EXISTS courses";
        sqLiteDatabase.execSQL(classifiesSql);
        sqLiteDatabase.execSQL(coursesSql);
        onCreate(sqLiteDatabase);
    }
}
