package vn.edu.stu.doangiuaky.model;

import java.io.Serializable;

public class Course implements Serializable {
    private Integer mamh;
    private String tenmh;
    private Integer gia;
    private Integer sotiet;
    private byte[] hinh;
    private Classify pl;

    public Course() {
    }

    public Course(Integer mamh, String tenmh, Integer gia, Integer sotiet, byte[] hinh, Classify pl) {
        this.mamh = mamh;
        this.tenmh = tenmh;
        this.gia = gia;
        this.sotiet = sotiet;
        this.hinh = hinh;
        this.pl = pl;
    }

    public Integer getMamh() {
        return mamh;
    }

    public void setMamh(Integer mamh) {
        this.mamh = mamh;
    }

    public String getTenmh() {
        return tenmh;
    }

    public void setTenmh(String tenmh) {
        this.tenmh = tenmh;
    }

    public Integer getGia() {
        return gia;
    }

    public void setGia(Integer gia) {
        this.gia = gia;
    }

    public Integer getSotiet() {
        return sotiet;
    }

    public void setSotiet(Integer sotiet) {
        this.sotiet = sotiet;
    }

    public byte[] getHinh() {
        return hinh;
    }

    public void setHinh(byte[] hinh) {
        this.hinh = hinh;
    }

    public Classify getPl() {
        return pl;
    }

    public void setPl(Classify pl) {
        this.pl = pl;
    }

    @Override
    public String toString() {
        return "Course{" +
                "mamh=" + mamh +
                ", tenmh='" + tenmh + '\'' +
                ", gia=" + gia +
                ", sotiet=" + sotiet +
                ", hinh=" + hinh +
                ", pl=" + pl +
                '}';
    }
}
