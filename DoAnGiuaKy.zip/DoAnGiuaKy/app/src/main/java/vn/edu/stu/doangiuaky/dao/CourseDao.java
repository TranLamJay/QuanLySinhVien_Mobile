package vn.edu.stu.doangiuaky.dao;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.sql.Blob;
import java.util.ArrayList;
import java.util.List;

import vn.edu.stu.doangiuaky.model.Classify;
import vn.edu.stu.doangiuaky.model.Course;
import vn.edu.stu.doangiuaky.utils.DbUtil;

public class CourseDao {
    private SQLiteDatabase db;

    public CourseDao(Context context) {
        DbUtil dbu = new DbUtil(context);
        this.db = dbu.getWritableDatabase();
    }


    public long insert(Course c) {
        ContentValues values = new ContentValues();
        values.put("mamh",c.getMamh());
        values.put("tenmh",c.getTenmh());
        values.put("gia",c.getGia());
        values.put("sotiet",c.getSotiet());
        values.put("hinh",c.getHinh());
        values.put("tenpl",c.getPl().getTenpl());
        values.put("classify_id",c.getPl().getMapl());
        return db.insert("courses",null,values);
    }

    @SuppressLint("Range")
    public List<Course> get(String sql, String ... selectArgs) {
        List<Course> list = new ArrayList<>();
        Cursor cursor = db.rawQuery(sql,selectArgs);
        while(cursor.moveToNext()) {
            Course c = new Course();
            Classify pl = new Classify();
            c.setMamh(cursor.getInt(cursor.getColumnIndex("mamh")));
            c.setTenmh(cursor.getString(cursor.getColumnIndex("tenmh")));
            c.setGia(cursor.getInt(cursor.getColumnIndex("gia")));
            c.setSotiet(cursor.getInt(cursor.getColumnIndex("sotiet")));
            c.setHinh(cursor.getBlob(cursor.getColumnIndex("hinh")));
            pl.setTenpl(cursor.getString(cursor.getColumnIndex("tenpl")));
            pl.setMapl(cursor.getInt(cursor.getColumnIndex("classify_id")));
            c.setPl(pl);
            list.add(c);
        }
        return list;
    }

    public List<Course> getAll() {
        String sql = "SELECT * FROM courses";
        return get(sql);
    }

    public List<Course> find(String id) {
        String sql = "SELECT * FROM courses where classify_id = "+id;
        return get(sql);
    }

    public int delete(String mamh) {
        return db.delete("courses","mamh=?",new String[]{mamh});
    }

    public long update(String mamh, Course c) {
        ContentValues values = new ContentValues();
        values.put("tenmh",c.getTenmh());
        values.put("gia",c.getGia());
        values.put("sotiet",c.getSotiet());
        values.put("hinh",c.getHinh());
        values.put("tenpl",c.getPl().getTenpl());
        values.put("classify_id",c.getPl().getMapl());
        return db.update("courses",values,"mamh=?",new String[]{mamh});
    }
}
