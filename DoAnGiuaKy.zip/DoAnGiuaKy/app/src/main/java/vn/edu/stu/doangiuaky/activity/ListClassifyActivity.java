package vn.edu.stu.doangiuaky.activity;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.util.List;

import vn.edu.stu.doangiuaky.R;
import vn.edu.stu.doangiuaky.adapter.ClassifyAdapter;
import vn.edu.stu.doangiuaky.dao.ClassifyDao;
import vn.edu.stu.doangiuaky.dao.CourseDao;
import vn.edu.stu.doangiuaky.model.Classify;
import vn.edu.stu.doangiuaky.model.Course;

public class ListClassifyActivity extends AppCompatActivity {
    private ListView lvPhanLoai;
    private List<Classify> list;
    private List<Course> cList;
    private ClassifyAdapter plAdapter;
    private ClassifyDao dao;
    private CourseDao cDao;
    int requestCode = 113, resultCode = 115;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_classify);
        addControls();
        addEvents();
        hienThiDSPhanLoai();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == this.requestCode) {
            if (resultCode == this.resultCode) {
                if (data.hasExtra("TRA")) {
                    Classify pl = (Classify) data.getSerializableExtra("TRA");
                    dao.update(pl.getMapl().toString(),pl);
                    hienThiDSPhanLoai();
                }
            }
        }
    }

    private void hienThiDSPhanLoai() {
        dao = new ClassifyDao(ListClassifyActivity.this);
        list = dao.getAll();
        plAdapter = new ClassifyAdapter(ListClassifyActivity.this,list);
        lvPhanLoai.setAdapter(plAdapter);
    }

    private void addEvents() {
        lvPhanLoai.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                if(i >= 0 && i < plAdapter.getCount()){
                    Intent intent = new Intent(ListClassifyActivity.this,ClassifyActivity.class);
                    Classify pl = (Classify) plAdapter.getItem(i);
                    boolean isEdit = true;
                    intent.putExtra("CHON",pl);
                    intent.putExtra("EDIT",isEdit);
                    startActivityForResult(intent,requestCode);
                }
            }
        });

        lvPhanLoai.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                if( i >= 0 && i < plAdapter.getCount()){
                    dao = new ClassifyDao(ListClassifyActivity.this);
                    Classify pl =(Classify) plAdapter.getItem(i);
                    xuLyXoa(pl.getMapl().toString());
                }
                return true;
            }
        });
    }

    private void xuLyXoa(String mapl) {
        AlertDialog.Builder builder = new AlertDialog.Builder(ListClassifyActivity.this);
        builder.setTitle("Thông báo");
        builder.setMessage("Bạn có chắc muốn xoá");
        builder.setIcon(R.drawable.alert_icon);
        builder.setPositiveButton("YES", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                cDao = new CourseDao(ListClassifyActivity.this);
                cList = cDao.find(mapl);
                if(cList.isEmpty()) {
                    dao.delete(mapl);
                    hienThiDSPhanLoai();
                    Context context = getApplicationContext();
                    Toast toast = Toast.makeText(context, "Xoá thành công !", Toast.LENGTH_SHORT);
                    toast.show();
                }
                else {
                    Context context = getApplicationContext();
                    Toast toast = Toast.makeText(context, "Có danh sách môn học không xoá được", Toast.LENGTH_SHORT);
                    toast.show();
                }
            }
        });
        builder.setNegativeButton("NO", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        });
        AlertDialog dialog = builder.create();
        dialog.setCanceledOnTouchOutside(false);
        dialog.show();
    }

    private void addControls() {
        lvPhanLoai = findViewById(R.id.lvPhanLoai);
    }
}