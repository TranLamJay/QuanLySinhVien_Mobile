package vn.edu.stu.doangiuaky.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import vn.edu.stu.doangiuaky.R;

public class OptionActivity extends AppCompatActivity {
    Button btnMonHoc, btnPhanLoai, btnHienThiMonHoc, btnHienThiPhanLoai;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_option);
        addControls();
        addEvents();
    }

    private void addEvents() {
        btnMonHoc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(OptionActivity.this, CourseActivity.class);
                startActivity(intent);
            }
        });
        btnHienThiMonHoc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(OptionActivity.this, ListCourseActivity.class);
                startActivity(intent);
            }
        });
        btnPhanLoai.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(OptionActivity.this,ClassifyActivity.class);
                startActivity(intent);
            }
        });
        btnHienThiPhanLoai.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(OptionActivity.this,ListClassifyActivity.class);
                startActivity(intent);
            }
        });
    }

    private void addControls() {
        btnMonHoc = findViewById(R.id.btnMonHoc);
        btnPhanLoai = findViewById(R.id.btnPhanLoai);
        btnHienThiMonHoc = findViewById(R.id.btnHienThiMonHoc);
        btnHienThiPhanLoai = findViewById(R.id.btnHienThiPhanLoai);
    }
}