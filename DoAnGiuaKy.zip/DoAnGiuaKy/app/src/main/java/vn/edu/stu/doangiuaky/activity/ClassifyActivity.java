package vn.edu.stu.doangiuaky.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import vn.edu.stu.doangiuaky.R;
import vn.edu.stu.doangiuaky.dao.ClassifyDao;
import vn.edu.stu.doangiuaky.model.Classify;

public class ClassifyActivity extends AppCompatActivity {
    private EditText etMaPhanLoai, etTenPhanLoai;
    private Button btnLuuPhanLoai;
    private Classify pl = null;
    int resultCode = 115;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_classify);
        addControlls();
        addEvents();
        getIntentData();
    }

    private void getIntentData() {
        Intent intent = getIntent();
        if(intent.hasExtra("CHON")) {
            pl =(Classify) intent.getSerializableExtra("CHON");
            if(pl != null) {
                etMaPhanLoai.setText(pl.getMapl().toString());
                etTenPhanLoai.setText(pl.getTenpl());
            }
        }
    }

    private void addEvents() {
        btnLuuPhanLoai.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                xuLyLuu();
            }
        });
    }

    private void xuLyLuu() {
        Intent intent = getIntent();
        if(intent.hasExtra("EDIT")) {
            pl.setTenpl(etTenPhanLoai.getText().toString());
            intent.putExtra("TRA", pl);
            setResult(resultCode, intent);
        }
        else {
            if(pl == null) {
                pl = new Classify();
            }
            pl.setTenpl(etTenPhanLoai.getText().toString());
            Context context = getApplicationContext();
            ClassifyDao dao = new ClassifyDao(context);
            dao.insert(pl);
        }
        finish();
        Context context = getApplicationContext();
        Toast toast = Toast.makeText(context, "Lưu thành công !", Toast.LENGTH_SHORT);
        toast.show();
    }

    private void addControlls() {
        etMaPhanLoai = findViewById(R.id.etMaPhanLoai);
        etMaPhanLoai.setEnabled(false);
        etMaPhanLoai.setFocusable(false);
        etTenPhanLoai = findViewById(R.id.etTenPhanLoai);
        btnLuuPhanLoai = findViewById(R.id.btnLuuPhanLoai);
    }
}